package com.example.app.model;

import java.io.Serializable;

//import java.io.Serializable;
import javax.persistence.*;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import lombok.Data;

import org.springframework.context.annotation.Scope;

@Data
@Scope("session")
@Entity
@Table(name = "employee")
public class Employee implements Serializable{
	@Id
	@Column(name = "employee_id")
	private Long empID;

	@Column(name = "employee_name")
	private String empname;

	@Column(name = "employee_pw")
	private String emppw;

	@Column(name = "employee_group")
	private String empgroup;
	
	public Employee(){
    }

	public Employee(Long empID, String empname, String emppw, String empgroup) {
		super();
		this.empID = empID;
		this.empname = empname;
		this.emppw = emppw;
		this.empgroup = empgroup;
	}

	public Long getEmpID() {
		return empID;
	}

	public void setEmpID(Long empID) {
		this.empID = empID;
	}

	public String getEmpname() {
		return empname;
	}
	
	public void setEmpname(String empname) {
		this.empname = empname;
	}

	public String getEmppw() {
		return emppw;
	}

	public void setEmppw(String emppw) {
		this.emppw = emppw;
	}



	public String getEmpgroup() {
		return empgroup;
	}

	public void setEmpgroup(String empgroup) {
		this.empgroup = empgroup;
	}

	@Override
	public String toString() {
		return "Tutorial [ id=" + empID + ", name=" + empname + ",pw=" + emppw + ", empgroup=" + empgroup + "]";
	}

}
