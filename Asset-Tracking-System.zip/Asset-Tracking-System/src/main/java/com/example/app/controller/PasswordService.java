//package com.example.app.controller;
//
//import org.springframework.context.annotation.Bean;
//import org.springframework.stereotype.Service;
//
//@Service
//public final class PasswordService {
//    @Bean
//    public BCrypt passwordEncoder() {
//        return new BCryptPasswordEncoder();
//    }
//}
